public class InputGetter {
}

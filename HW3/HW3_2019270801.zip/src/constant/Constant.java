package constant;

public class Constant {

    public static final int MIN_X = 0;
    public static final int MAX_X = 9;

    public static final int MIN_Y = 0;
    public static final int MAX_Y = 9;

    public static final int BOARD_SIZE = 10;

    public static final int CNT_DIVIDER = 0;

    public static final int MAX_LAP = 3;

    public static final int PLAYER_DICE_NUM = 6;

    public static final int COMPUTER_DICE_NUM = 3;

    public static final int MAX_CNT = 40;

    public static final int DICE_1 = 1;

    public static final int DICE_2 = 2;

    public static final int DICE_3 = 3;




}

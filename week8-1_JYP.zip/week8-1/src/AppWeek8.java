import engine.Engine;

public class AppWeek8 {

    public static void main(String[] args) {
        Engine engine = Engine.getInstance();
        engine.init();




    }

}

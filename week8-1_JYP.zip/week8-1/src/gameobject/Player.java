package gameobject;

public class Player extends Unit{

    public Player() {

    }
}

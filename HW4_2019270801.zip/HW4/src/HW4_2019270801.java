import engine.Engine;

public class HW4_2019270801 {

    public static void main(String [] args){
        Engine engine = Engine.getInstance();
        engine.init();

    }
}
